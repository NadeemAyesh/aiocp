import { Component, OnInit, OnDestroy, inject, signal, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WebsiteDataService } from '../../services/website-data.service';
import { HeroSlide } from '../../models/website.models';

@Component({
  selector: 'app-hero-slider',
  standalone: true,
  imports: [CommonModule],
  template: `
    <!-- Hero Section (Light Canvas with Skyline Background - No Dark Blue) -->
    <section id="hero" class="relative overflow-hidden pt-6 sm:pt-10 pb-16 lg:pb-20 bg-gradient-to-b from-white via-[#f4f9fd] to-[#eef6fc]">
      
      <!-- Ambient Atmospheric Light Glows -->
      <div class="absolute top-0 right-1/4 w-[500px] h-[500px] bg-sky-400/10 rounded-full blur-3xl pointer-events-none -z-0"></div>
      <div class="absolute top-1/3 left-1/4 w-[450px] h-[450px] bg-amber-400/10 rounded-full blur-3xl pointer-events-none -z-0"></div>

      <!-- The Official Palestinian Skyline Silhouette in the Background -->
      <div class="hero-skyline" aria-hidden="true"></div>

      <!-- Main Slider Container (z-10 on top of skyline) -->
      <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Top Split Grid: Story Content on Right & Framed Image on Left (in RTL) -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center mb-12">
          
          <!-- Content Column (Span 7 in RTL) -->
          <div class="lg:col-span-7 space-y-6">
            
            <!-- Category & Live Badge -->
            <div class="flex flex-wrap items-center gap-3">
              <span class="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-black bg-[#f4921e]/15 text-[#b86100] border border-[#f4921e]/30">
                <span class="w-2 h-2 rounded-full bg-[#f4921e] animate-ping"></span>
                <span>{{ activeSlide.badge }}</span>
              </span>

              <span class="px-3 py-1 rounded-full text-xs font-bold bg-white text-[#004380] border border-slate-200 shadow-sm">
                {{ activeSlide.category }}
              </span>

              <div class="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                <svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                <span>{{ activeSlide.date }}</span>
                <span>•</span>
                <span>قراءة {{ activeSlide.readTime }}</span>
              </div>
            </div>

            <!-- Active Headline in Deep Navy (100% Legible & Punchy) -->
            <h1 class="text-3xl sm:text-4xl lg:text-5xl font-black text-[#00284d] leading-[1.3] tracking-tight transition-all duration-300">
              {{ activeSlide.title }}
            </h1>

            <!-- Editorial Excerpt -->
            <p class="text-slate-600 text-base sm:text-lg leading-relaxed font-normal max-w-2xl">
              {{ activeSlide.excerpt }}
            </p>

            <!-- Metrics Pill -->
            <div *ngIf="activeSlide.projectTarget" class="inline-flex items-center gap-3 p-3 rounded-2xl bg-white border border-slate-200/90 shadow-sm text-xs font-bold text-[#004380]">
              <div class="w-8 h-8 rounded-xl bg-blue-50 text-[#004380] flex items-center justify-center font-black">
                $
              </div>
              <div class="space-y-0.5">
                <span class="block text-slate-400 text-[10px]">المستهدف الإغاثي</span>
                <span class="block font-black text-sm text-[#00284d]">{{ activeSlide.projectTarget }}</span>
              </div>
            </div>

            <!-- Action CTAs -->
            <div class="flex flex-wrap items-center gap-4 pt-2">
              <!-- Primary Action Blue Button -->
              <a 
                [href]="activeSlide.actionLink"
                class="px-7 py-3.5 rounded-2xl bg-[#004380] hover:bg-[#00284d] text-white font-bold text-sm sm:text-base shadow-xl hover:shadow-blue-900/20 hover:scale-105 active:scale-95 transition-all duration-200 flex items-center gap-2 group"
              >
                <span>اقرأ التقرير الميداني</span>
                <svg class="w-4 h-4 transform group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
              </a>

              <!-- Warm Orange Donate Button -->
              <button 
                (click)="donateTrigger.emit()"
                class="px-7 py-3.5 rounded-2xl bg-gradient-to-r from-[#f4921e] to-[#de7c0d] hover:from-[#ff9e2e] hover:to-[#f4921e] text-white font-black text-sm sm:text-base shadow-xl hover:shadow-orange-500/25 hover:scale-105 active:scale-95 transition-all duration-200 flex items-center gap-2"
              >
                <svg class="w-4 h-4 fill-current text-white" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                <span>تبرع الآن</span>
              </button>
            </div>

            <!-- Slide Nav Buttons & Counter -->
            <div class="flex items-center gap-4 pt-3">
              <div class="flex items-center gap-1.5">
                <button 
                  (click)="prevSlide()" 
                  class="w-9 h-9 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 flex items-center justify-center transition shadow-sm"
                  title="السابق"
                >
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </button>
                <button 
                  (click)="nextSlide()" 
                  class="w-9 h-9 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 flex items-center justify-center transition shadow-sm"
                  title="التالي"
                >
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                </button>
              </div>

              <!-- Slide Indicators -->
              <div class="flex items-center gap-1.5">
                <button 
                  *ngFor="let s of slides; let i = index"
                  (click)="goToSlide(i)"
                  class="h-2 rounded-full transition-all duration-300"
                  [class.w-8]="currentSlide() === i"
                  [class.bg-[#f4921e]]="currentSlide() === i"
                  [class.w-2]="currentSlide() !== i"
                  [class.bg-slate-300]="currentSlide() !== i"
                  [title]="s.title"
                ></button>
              </div>

              <span class="text-xs font-mono font-bold text-slate-400">
                0{{ currentSlide() + 1 }} / 0{{ slides.length }}
              </span>
            </div>

          </div>

          <!-- Visual Showcase Column (Framed Photo Card on Left in RTL) -->
          <div class="lg:col-span-5">
            <div class="relative">
              
              <!-- Framed Active News Photo with Glow & Shadows -->
              <div class="relative rounded-3xl overflow-hidden border-4 border-white shadow-2xl bg-white aspect-[4/3] sm:aspect-[16/11]">
                <img 
                  [src]="activeSlide.image" 
                  [alt]="activeSlide.title" 
                  class="w-full h-full object-cover transition-all duration-700 ease-out"
                />
                
                <!-- Bottom Gradient Tag inside frame -->
                <div class="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent"></div>

                <!-- Top-Right Category Pill -->
                <span class="absolute top-4 right-4 px-3.5 py-1.5 rounded-xl text-xs font-black bg-[#00284d]/90 text-white backdrop-blur-md border border-white/20 shadow">
                  {{ activeSlide.category }}
                </span>

                <!-- Bottom Photo Caption -->
                <div class="absolute bottom-4 right-4 left-4 text-white">
                  <span class="text-[11px] font-bold text-[#f4921e] block mb-0.5">
                    توثيق ميداني معتمد
                  </span>
                  <p class="text-xs sm:text-sm font-bold text-white/95 line-clamp-2">
                    {{ activeSlide.title }}
                  </p>
                </div>
              </div>

              <!-- Floating Live Metric Badge -->
              <div class="absolute -bottom-5 -right-4 sm:-right-6 bg-white rounded-2xl p-4 shadow-xl border border-slate-200/90 flex items-center gap-3 animate-bounce-gentle">
                <div class="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-black">
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </div>
                <div>
                  <span class="block text-xs text-slate-400 font-bold">حالة التنفيذ</span>
                  <span class="block text-sm font-black text-[#00284d]">جاهزية هندسية كاملة</span>
                </div>
              </div>

            </div>
          </div>

        </div>

        <!-- 4 Interactive Story Cards Deck (Positioned Above Skyline) -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12 relative z-10">
          <div 
            *ngFor="let s of slides; let idx = index"
            (click)="goToSlide(idx)"
            class="cursor-pointer bg-white/95 backdrop-blur-md rounded-2xl p-4 border transition-all duration-300 hover:shadow-xl flex flex-col justify-between"
            [class.border-[#f4921e]]="currentSlide() === idx"
            [class.shadow-lg]="currentSlide() === idx"
            [class.ring-2]="currentSlide() === idx"
            [class.ring-[#f4921e]/20]="currentSlide() === idx"
            [class.border-slate-200]="currentSlide() !== idx"
          >
            <div class="flex items-center gap-3 mb-2.5">
              <img [src]="s.image" [alt]="s.title" class="w-13 h-13 rounded-xl object-cover border border-slate-100 flex-shrink-0" />
              <div class="min-w-0 flex-1">
                <span class="block text-[11px] font-extrabold text-[#f4921e]">{{ s.badge }}</span>
                <span class="block text-[10px] text-slate-400 font-medium">{{ s.date }}</span>
              </div>
            </div>

            <h4 class="text-xs font-bold text-[#00284d] line-clamp-2 leading-snug">
              {{ s.title }}
            </h4>

            <!-- Active Progress Timer Bar -->
            <div *ngIf="currentSlide() === idx" class="mt-3 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
              <div class="h-full bg-[#f4921e] animate-timerBar"></div>
            </div>
          </div>
        </div>

        <!-- Confidence Metrics Bar (Light Card Styling) -->
        <div class="bg-white/95 backdrop-blur-md rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xl relative z-10">
          <div class="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center divide-y lg:divide-y-0 lg:divide-x lg:divide-x-reverse divide-slate-100">
            
            <div class="pt-2 lg:pt-0 space-y-1">
              <span class="block text-2xl sm:text-3xl font-black text-[#004380] font-display">+29M$</span>
              <span class="block text-xs font-bold text-slate-800">مذكرات شراكة دولية</span>
              <span class="block text-[11px] text-slate-500">تمويل مباشر لمشاريع الطوارئ</span>
            </div>

            <div class="pt-2 lg:pt-0 space-y-1">
              <span class="block text-2xl sm:text-3xl font-black text-[#f4921e] font-display">+1,500,000</span>
              <span class="block text-xs font-bold text-slate-800">مستفيد ومستفيدة</span>
              <span class="block text-[11px] text-slate-500">في قطاعات الإيواء والمياه والصحة</span>
            </div>

            <div class="pt-2 lg:pt-0 space-y-1">
              <span class="block text-2xl sm:text-3xl font-black text-emerald-600 font-display">+450</span>
              <span class="block text-xs font-bold text-slate-800">مشروع هندسي منجز</span>
              <span class="block text-[11px] text-slate-500">بمعايير جودة ورقابة دولية</span>
            </div>

            <div class="pt-2 lg:pt-0 space-y-1">
              <span class="block text-2xl sm:text-3xl font-black text-slate-700 font-display">15+ عاماً</span>
              <span class="block text-xs font-bold text-slate-800">من العطاء المؤسسي</span>
              <span class="block text-[11px] text-slate-500">خبرة متخصصة ومصداقية رفيعة</span>
            </div>

          </div>
        </div>

        <!-- Breaking News Ticker Strip -->
        <div class="mt-8 bg-white border border-slate-200 rounded-2xl p-3 shadow-sm flex items-center gap-4 text-xs overflow-hidden relative z-10">
          <div class="flex-shrink-0 flex items-center gap-2 font-bold text-[#b86100] bg-orange-50 px-3 py-1.5 rounded-xl border border-orange-200">
            <span class="w-2 h-2 rounded-full bg-[#f4921e] animate-ping"></span>
            <span>تحديثات عاجلة:</span>
          </div>
          <div class="overflow-hidden relative flex-1">
            <div class="whitespace-nowrap flex items-center gap-8 animate-ticker text-slate-600 font-medium">
              <span *ngFor="let item of breakingNews" class="inline-flex items-center gap-2">
                <span class="text-[#004380]">✦</span>
                <span>{{ item }}</span>
              </span>
            </div>
          </div>
        </div>

      </div>
    </section>
  `,
  styles: [`
    /* Exact AIOCP Skyline Vector Silhouette in Background */
    .hero-skyline {
      position: absolute;
      inset-inline: 0;
      bottom: 0;
      margin-inline: auto;
      width: 100%;
      max-width: 1400px;
      height: 280px;
      pointer-events: none;
      background: linear-gradient(to top, rgba(0, 142, 205, 0.22) 0%, rgba(0, 142, 205, 0.05) 65%, transparent 100%);
      -webkit-mask-image: url('/images/skyline-pair.svg');
      mask-image: url('/images/skyline-pair.svg');
      -webkit-mask-repeat: no-repeat;
      mask-repeat: no-repeat;
      -webkit-mask-position: bottom center;
      mask-position: bottom center;
      -webkit-mask-size: 100% 100%;
      mask-size: 100% 100%;
      z-index: 1;
    }

    @media (max-width: 768px) {
      .hero-skyline {
        height: 180px;
        -webkit-mask-image: url('/images/skyline.svg');
        mask-image: url('/images/skyline.svg');
      }
    }

    @keyframes timerBar {
      from { width: 0%; }
      to { width: 100%; }
    }
    .animate-timerBar {
      animation: timerBar 6s linear infinite;
    }
    @keyframes ticker {
      0% { transform: translateX(0); }
      100% { transform: translateX(50%); }
    }
    .animate-ticker {
      display: inline-flex;
      animation: ticker 28s linear infinite;
    }
    .animate-ticker:hover {
      animation-play-state: paused;
    }
    @keyframes bounceGentle {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-4px); }
    }
    .animate-bounce-gentle {
      animation: bounceGentle 3s ease-in-out infinite;
    }
  `]
})
export class HeroSliderComponent implements OnInit, OnDestroy {
  @Output() donateTrigger = new EventEmitter<void>();

  private dataService = inject(WebsiteDataService);
  slides: HeroSlide[] = this.dataService.heroSlides;
  breakingNews: string[] = this.dataService.breakingNews;

  currentSlide = signal(0);
  private timer: any;

  get activeSlide(): HeroSlide {
    return this.slides[this.currentSlide()];
  }

  ngOnInit() {
    this.startAutoPlay();
  }

  ngOnDestroy() {
    this.stopAutoPlay();
  }

  startAutoPlay() {
    this.stopAutoPlay();
    this.timer = setInterval(() => {
      this.nextSlide();
    }, 6000);
  }

  stopAutoPlay() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  nextSlide() {
    this.currentSlide.update(i => (i + 1) % this.slides.length);
  }

  prevSlide() {
    this.currentSlide.update(i => (i - 1 + this.slides.length) % this.slides.length);
  }

  goToSlide(idx: number) {
    this.currentSlide.set(idx);
    this.startAutoPlay();
  }
}
